package com.turimstransac.turismo.repositories;

import com.turimstransac.turismo.models.Plan;
import java.util.List;

import com.turimstransac.turismo.models.Reserva;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface ReservaRepository extends MongoRepository <Plan, String>{
    List <Reserva> findByid (String username);
    List <Reserva> findByplanid (String planid);



}
