package com.turimstransac.turismo.controllers;

import com.turimstransac.turismo.exceptions.PlanNotFoundException;
import com.turimstransac.turismo.models.Reserva;
import com.turimstransac.turismo.models.Plan;
import com.turimstransac.turismo.repositories.PlanRepository;
import com.turimstransac.turismo.repositories.ReservaRepository;
import org.springframework.web.bind.annotation.*;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class ReservaController {
    private final PlanRepository planRepository;
    private final ReservaRepository reservaRepository;

    public ReservaController(PlanRepository planRepository, ReservaRepository reservaRepository) {
        this.planRepository = planRepository;
        this.reservaRepository = reservaRepository;
    }
    @PostMapping("/reservas")
    Reserva newReserva(@RequestBody Reserva reserva) {
        Plan id = planRepository.findById(reserva.getId()).orElse(null);
        Plan idplan = planRepository.findById(reserva.getIdplan()).orElse(null);

        if (idplan== null)
            throw new PlanNotFoundException("No se encontro un plan con el username: " + reserva.getId());


        return reservaRepository.save(reserva);
    }
}
