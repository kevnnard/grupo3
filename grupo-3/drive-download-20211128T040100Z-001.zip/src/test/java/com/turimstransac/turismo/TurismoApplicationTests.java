package com.turimstransac.turismo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TurismoApplicationTests {

	@Test
	void contextLoads() {
	}

}
